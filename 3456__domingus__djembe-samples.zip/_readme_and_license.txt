Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by domingus ( http://www.freesound.org/people/domingus/  )
You can find this pack online at: http://www.freesound.org/people/domingus/packs/3456/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 54022__domingus__DJEMBE_MID_2.wav
    * url: http://www.freesound.org/people/domingus/sounds/54022/
    * license: Creative Commons 0
  * 54021__domingus__DJEMBE_MID_1.wav
    * url: http://www.freesound.org/people/domingus/sounds/54021/
    * license: Creative Commons 0
  * 54019__domingus__DJEMBE_LO_3.wav
    * url: http://www.freesound.org/people/domingus/sounds/54019/
    * license: Creative Commons 0
  * 54023__domingus__DJEMBE_MID_3.wav
    * url: http://www.freesound.org/people/domingus/sounds/54023/
    * license: Creative Commons 0
  * 54020__domingus__DJEMBE_LO_KING.wav
    * url: http://www.freesound.org/people/domingus/sounds/54020/
    * license: Creative Commons 0
  * 54018__domingus__DJEMBE_LO_2.wav
    * url: http://www.freesound.org/people/domingus/sounds/54018/
    * license: Creative Commons 0
  * 54024__domingus__DJEMBE_MID_4.wav
    * url: http://www.freesound.org/people/domingus/sounds/54024/
    * license: Creative Commons 0
  * 54025__domingus__DJEMBE_TICK.wav
    * url: http://www.freesound.org/people/domingus/sounds/54025/
    * license: Creative Commons 0
  * 54013__domingus__DJEMBE_DOBLE.wav
    * url: http://www.freesound.org/people/domingus/sounds/54013/
    * license: Creative Commons 0
  * 54015__domingus__DJEMBE_HI_2.wav
    * url: http://www.freesound.org/people/domingus/sounds/54015/
    * license: Creative Commons 0
  * 54016__domingus__DJEMBE_HI_3.wav
    * url: http://www.freesound.org/people/domingus/sounds/54016/
    * license: Creative Commons 0
  * 54014__domingus__DJEMBE_HI_1.wav
    * url: http://www.freesound.org/people/domingus/sounds/54014/
    * license: Creative Commons 0
  * 54017__domingus__DJEMBE_LO_1.wav
    * url: http://www.freesound.org/people/domingus/sounds/54017/
    * license: Creative Commons 0

